
            ship.update()